/**
 * COPY CAT Pro — Isolated World Content Script (Ultimate Fallback)
 *
 * Includes manual fallback copying (bypassing native limitations completely)
 * and aggressive CSS/Observer unlocking.
 */

(function () {
  "use strict";

  var active = true;

  /* ================================================================
   *  isInteractive
   * ================================================================ */
  function isInteractive(el) {
    if (!el || el.nodeType !== 1) return false;

    var tag = el.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" ||
        tag === "BUTTON" || tag === "OPTION" || tag === "LABEL" ||
        tag === "DETAILS" || tag === "SUMMARY") return true;

    if (el.isContentEditable) return true;

    var role = el.getAttribute && el.getAttribute("role");
    if (role === "textbox" || role === "listbox" || role === "combobox" ||
        role === "option" || role === "button" || role === "menuitem" ||
        role === "menu" || role === "dialog" || role === "switch" ||
        role === "slider" || role === "spinbutton" || role === "tab" ||
        role === "tabpanel") return true;

    var p = el.parentElement;
    var depth = 0;
    while (p && depth < 5) {
      var pt = p.tagName;
      if (pt === "INPUT" || pt === "TEXTAREA" || pt === "SELECT" ||
          pt === "BUTTON") return true;
      if (p.isContentEditable) return true;
      var pr = p.getAttribute && p.getAttribute("role");
      if (pr === "textbox" || pr === "listbox" || pr === "combobox" ||
          pr === "menu" || pr === "dialog" || pr === "menuitem") return true;
      p = p.parentElement;
      depth++;
    }
    return false;
  }

  /* ================================================================
   *  MANUAL CLIPBOARD INJECTION FALLBACK
   *  If the site completely breaks browser native copy, we just do it ourselves
   * ================================================================ */
  function fallbackCopyText(text) {
    if (!text || text.trim() === "") return;
    try {
      navigator.clipboard.writeText(text);
    } catch(e) {
      try {
        var ta = document.createElement("textarea");
        ta.value = text;
        ta.style.position = "fixed";
        ta.style.left = "-9999px";
        ta.setAttribute("readonly", "");
        document.body.appendChild(ta);
        ta.select();
        document.execCommand("copy");
        document.body.removeChild(ta);
      } catch(err) {}
    }
  }

  function handleManualCopy() {
    var text = window.getSelection().toString();
    if (text) {
      fallbackCopyText(text);
    }
  }

  /* ================================================================
   *  EVENT HANDLERS
   * ================================================================ */
  function onClipboard(e) {
    if (!active) return;
    if (isInteractive(e.target)) return;
    
    e.stopPropagation();
    e.stopImmediatePropagation();

    // On copy/cut, artificially inject into clipboard just to be absolutely sure
    if (e.type === "copy" || e.type === "cut") {
      handleManualCopy();
    }
  }

  function onKeyDown(e) {
    if (!active) return;
    if (!(e.ctrlKey || e.metaKey)) return;
    var k = (e.key || "").toLowerCase();
    if (k !== "c" && k !== "v" && k !== "x" && k !== "a") return;
    if (isInteractive(e.target)) return;
    
    e.stopPropagation();
    e.stopImmediatePropagation();

    // If it's a copy or cut shortcut, trigger the manual fallback copy
    if (k === "c" || k === "x") {
      handleManualCopy();
    }
  }

  function attachListeners() {
    document.addEventListener("copy",        onClipboard, true);
    document.addEventListener("cut",         onClipboard, true);
    document.addEventListener("paste",       onClipboard, true);
    document.addEventListener("contextmenu", onClipboard, true);
    document.addEventListener("selectstart", onClipboard, true);
    document.addEventListener("keydown",     onKeyDown,   true);
  }

  function detachListeners() {
    document.removeEventListener("copy",        onClipboard, true);
    document.removeEventListener("cut",         onClipboard, true);
    document.removeEventListener("paste",       onClipboard, true);
    document.removeEventListener("contextmenu", onClipboard, true);
    document.removeEventListener("selectstart", onClipboard, true);
    document.removeEventListener("keydown",     onKeyDown,   true);
  }

  /* ================================================================
   *  CSS — <style> tag
   * ================================================================ */
  var STYLE_ID = "__ccpro__";

  function injectCSS() {
    if (document.getElementById(STYLE_ID)) return;
    var s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent =
      "*,*::before,*::after{" +
        "-webkit-user-select:text!important;" +
        "-moz-user-select:text!important;" +
        "user-select:text!important;" +
        "-webkit-touch-callout:default!important;" +
        "pointer-events:auto;" + // Ensures text pointer isn't blocked by generic transparent wrappers
      "}";
    var parent = document.head || document.documentElement;
    if (parent) parent.appendChild(s);
  }

  function removeCSS() {
    var el = document.getElementById(STYLE_ID);
    if (el) el.remove();
  }

  /* ── Inline style on individual elements ──────────────────────── */
  function forceSelect(el) {
    if (!el || !el.style) return;
    try {
      el.style.setProperty("user-select", "text", "important");
      el.style.setProperty("-webkit-user-select", "text", "important");
    } catch (e) {}
  }

  function forceSelectGlobal() {
    forceSelect(document.documentElement);
    if (document.body) forceSelect(document.body);
    var all = document.querySelectorAll("*");
    for (var i = 0; i < all.length; i++) {
      if (!isInteractive(all[i])) forceSelect(all[i]);
    }
  }

  /* ================================================================
   *  NULLIFY DOCUMENT HANDLERS & ATTRIBUTES
   * ================================================================ */
  var HANDLER_PROPS = ["oncopy", "oncut", "onpaste", "oncontextmenu", "onselectstart"];
  var BLOCKED_ATTRS = [
    "oncopy", "oncut", "onpaste", "oncontextmenu",
    "onselectstart", "onbeforecopy", "onbeforecut", "onbeforepaste"
  ];

  function nullifyHandlers() {
    var targets = [document, document.documentElement];
    if (document.body) targets.push(document.body);
    for (var i = 0; i < targets.length; i++) {
      for (var j = 0; j < HANDLER_PROPS.length; j++) {
        try { targets[i][HANDLER_PROPS[j]] = null; } catch (e) {}
      }
    }
  }

  function cleanAttrs(el) {
    if (!el || !el.hasAttribute) return;
    for (var i = 0; i < BLOCKED_ATTRS.length; i++) {
      if (el.hasAttribute(BLOCKED_ATTRS[i])) el.removeAttribute(BLOCKED_ATTRS[i]);
    }
  }

  function cleanAllAttrs() {
    cleanAttrs(document.documentElement);
    if (document.body) cleanAttrs(document.body);
    document.querySelectorAll("*").forEach(cleanAttrs);
  }

  /* ================================================================
   *  SHADOW DOM
   * ================================================================ */
  function walkShadow(root) {
    if (!root || !root.querySelectorAll) return;
    root.querySelectorAll("*").forEach(function (el) {
      cleanAttrs(el);
      if (!isInteractive(el)) forceSelect(el);
      if (el.shadowRoot) {
        walkShadow(el.shadowRoot);
        try {
          if (!el.shadowRoot.getElementById(STYLE_ID)) {
            var s = document.createElement("style");
            s.id = STYLE_ID;
            s.textContent = "*{-webkit-user-select:text!important;user-select:text!important}";
            el.shadowRoot.appendChild(s);
          }
        } catch (e) {}
      }
    });
  }

  /* ================================================================
   *  MUTATION OBSERVER
   * ================================================================ */
  var observer = null;

  function startObserver() {
    if (observer) return;
    var root = document.documentElement || document.body;
    if (!root) return;

    observer = new MutationObserver(function (muts) {
      if (!active) return;
      var dirty = false;

      for (var i = 0; i < muts.length; i++) {
        var m = muts[i];
        for (var j = 0; j < m.addedNodes.length; j++) {
          var node = m.addedNodes[j];
          if (node.nodeType !== 1) continue;
          cleanAttrs(node);
          if (!isInteractive(node)) forceSelect(node);
          if (node.querySelectorAll) {
            node.querySelectorAll("*").forEach(function (c) {
              cleanAttrs(c);
              if (!isInteractive(c)) forceSelect(c);
            });
          }
          if (node.shadowRoot) walkShadow(node.shadowRoot);
          dirty = true;
        }

        if (m.type === "attributes" && m.target && m.target.nodeType === 1) {
          cleanAttrs(m.target);
          if (!isInteractive(m.target)) forceSelect(m.target);
          dirty = true;
        }
      }

      if (dirty) {
        nullifyHandlers();
        injectCSS(); 
      }
    });

    observer.observe(root, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: BLOCKED_ATTRS.concat(["style", "class"])
    });
  }

  function stopObserver() {
    if (observer) { observer.disconnect(); observer = null; }
  }

  /* ================================================================
   *  OVERLAY DETECTION
   * ================================================================ */
  function neutralizeOverlays() {
    if (!document.body) return;
    var vw = window.innerWidth, vh = window.innerHeight;
    var all = document.querySelectorAll("*");

    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (isInteractive(el)) continue;
      var tag = el.tagName;
      if (tag === "NAV" || tag === "HEADER" || tag === "FOOTER" ||
          tag === "MAIN" || tag === "DIALOG" || tag === "ASIDE" ||
          tag === "SECTION" || tag === "IMG" || tag === "VIDEO") continue;
      if (el.children.length > 2) continue;

      var cs;
      try { cs = window.getComputedStyle(el); } catch (e) { continue; }
      var pos = cs.position;
      if (pos !== "fixed" && pos !== "absolute") continue;

      var zi = parseInt(cs.zIndex, 10);
      if (isNaN(zi) || zi < 50) continue;

      var rect = el.getBoundingClientRect();
      if (rect.width < vw * 0.4 || rect.height < vh * 0.4) continue;

      var opacity = parseFloat(cs.opacity);
      var bg = cs.backgroundColor;
      var isTransp = (opacity < 0.15) || (bg === "transparent") || (bg === "rgba(0, 0, 0, 0)");
      if (isTransp) {
        el.style.setProperty("pointer-events", "none", "important");
      }
    }
  }

  /* ================================================================
   *  CLEANUP PASSES
   * ================================================================ */
  function fullClean() {
    injectCSS();
    forceSelectGlobal();
    nullifyHandlers();
    cleanAllAttrs();
    walkShadow(document.documentElement);
    neutralizeOverlays();
  }

  var timer = null;

  function startTimer() {
    if (timer) return;
    var count = 0;
    timer = setInterval(function () {
      if (!active) return;
      nullifyHandlers();
      forceSelect(document.documentElement);
      if (document.body) forceSelect(document.body);
      injectCSS();
      count++;
      if (count >= 120) { clearInterval(timer); timer = null; }
    }, 500);
  }

  function stopTimer() {
    if (timer) { clearInterval(timer); timer = null; }
  }

  /* ================================================================
   *  ACTIVATE / DEACTIVATE
   * ================================================================ */
  function activate() {
    active = true;
    attachListeners();
    if (document.body || document.documentElement) fullClean();
    startObserver();
    startTimer();
  }

  function deactivate() {
    active = false;
    detachListeners();
    removeCSS();
    stopObserver();
    stopTimer();
  }

  /* ================================================================
   *  BOOT
   * ================================================================ */
  attachListeners();

  chrome.storage.local.get(["enabled"], function (r) {
    if ((r.enabled !== undefined) ? r.enabled : true) activate(); else deactivate();
  });

  chrome.storage.onChanged.addListener(function (c, area) {
    if (area === "local" && c.enabled) {
      c.enabled.newValue ? activate() : deactivate();
    }
  });

  document.addEventListener("DOMContentLoaded", function () {
    if (active) { fullClean(); startObs(); }
  }, { once: true });

  window.addEventListener("load", function () {
    if (!active) return;
    fullClean();
    var delays = [500, 1500, 3000, 6000, 10000];
    delays.forEach(function(d) {
      setTimeout(function () { if (active) fullClean(); }, d);
    });
  }, { once: true });

})();
