Put your image here and name it icon.png (so the path is icons/icon.png)
