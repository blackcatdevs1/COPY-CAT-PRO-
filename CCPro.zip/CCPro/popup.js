/**
 * COPY CAT Pro — Minimalist Hacker UI Logic
 */

document.addEventListener('DOMContentLoaded', () => {
    const btnEnable = document.getElementById('btnEnable');
    const btnDisable = document.getElementById('btnDisable');
    const statusBadge = document.getElementById('statusBadge');
    const btnEnableText = document.getElementById('btnEnableText');

    function updateUI(isEnabled) {
        if (isEnabled) {
            statusBadge.textContent = 'ONLINE';
            statusBadge.className = 'status-badge online';
            
            // Primary button active state
            btnEnableText.textContent = 'BYPASS ENABLED';
            btnEnable.style.background = '#ffffff';
            btnEnable.style.color = '#000000';
            btnEnable.style.opacity = '1';
            
            // Secondary button dim
            btnDisable.style.opacity = '0.5';
        } else {
            statusBadge.textContent = 'OFFLINE';
            statusBadge.className = 'status-badge';
            
            // Primary button dim
            btnEnableText.textContent = 'ENABLE BYPASS';
            btnEnable.style.opacity = '0.5';
            
            // Secondary button active
            btnDisable.style.opacity = '1';
        }
    }

    // Load initial state
    chrome.storage.local.get(['enabled'], (result) => {
        const isEnabled = result.enabled !== undefined ? result.enabled : true;
        updateUI(isEnabled);
    });

    btnEnable.addEventListener('click', () => {
        chrome.storage.local.set({ enabled: true }, () => {
            updateUI(true);
        });
    });

    btnDisable.addEventListener('click', () => {
        chrome.storage.local.set({ enabled: false }, () => {
            updateUI(false);
        });
    });
});
