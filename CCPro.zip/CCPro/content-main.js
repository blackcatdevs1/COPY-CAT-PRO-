/**
 * COPY CAT Pro — MAIN World Script (Ultimate Fallback)
 *
 * Runs in the PAGE'S JavaScript world (world: "MAIN" in manifest).
 * This overrides APIs the site uses to lock down the page.
 */

(function () {
  "use strict";

  // ═══════════════════════════════════════════════════════════════
  //  1. Override Event.prototype.preventDefault
  //     Blocks the site from cancelling copy events OR keyboard shortcuts
  // ═══════════════════════════════════════════════════════════════
  var BLOCKED_TYPES = {
    "copy": true,
    "cut": true,
    "paste": true,
    "selectstart": true,
    "contextmenu": true,
    "dragstart": true
  };

  var _preventDefault = Event.prototype.preventDefault;

  Event.prototype.preventDefault = function () {
    var t = this.type;
    
    // Block preventDefault on copy/select/contextmenu
    if (BLOCKED_TYPES[t]) {
      return; // silently ignore
    }

    // Block preventDefault on Ctrl+C / Ctrl+V / Ctrl+X / Ctrl+A
    if (t === "keydown" && (this.ctrlKey || this.metaKey)) {
      var k = (this.key || "").toLowerCase();
      if (k === "c" || k === "v" || k === "x" || k === "a") {
        return; // silently ignore, let shortcut proceed natively
      }
    }

    // All other events pass through
    return _preventDefault.apply(this, arguments);
  };

  // ═══════════════════════════════════════════════════════════════
  //  2. Override Selection APIs
  //     Prevents sites from programmatically clearing selections
  // ═══════════════════════════════════════════════════════════════
  var selMethods = [
    "removeAllRanges",
    "empty",
    "collapse",
    "collapseToEnd",
    "collapseToStart",
    "deleteFromDocument",
    "removeRange"
  ];
  
  for (var i = 0; i < selMethods.length; i++) {
    var method = selMethods[i];
    if (Selection.prototype[method]) {
      Selection.prototype[method] = function () {
        return; // no-op — protect selection
      };
    }
  }

  // ═══════════════════════════════════════════════════════════════
  //  3. Override Clipboard / DataTransfer APIs
  //     Prevents sites from replacing the copied text with empty space
  // ═══════════════════════════════════════════════════════════════
  if (typeof DataTransfer !== "undefined" && DataTransfer.prototype) {
    if (DataTransfer.prototype.setData) {
      var _setData = DataTransfer.prototype.setData;
      DataTransfer.prototype.setData = function (format, data) {
        // Block empty data from overwriting real text
        if (!data || data.trim() === "") return;
        return _setData.apply(this, arguments);
      };
    }
    if (DataTransfer.prototype.clearData) {
      DataTransfer.prototype.clearData = function () {
        return; // no-op
      };
    }
  }

})();
